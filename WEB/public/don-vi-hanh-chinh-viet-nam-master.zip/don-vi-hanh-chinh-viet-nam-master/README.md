# DATABASE DANH SÁCH ĐƠN VỊ HÀNH CHÍNH VIỆT NAM
Cập nhật tháng 10/2017

Nguồn trích xuất từ Tổng cục Thống kê (http://www.gso.gov.vn/dmhc2015/)

Định dạng database: Excel, SQLite3, MySQL
